clc 
clear all 
close all
 



% Impedence
z12 = 0.02+0.04i;
z13 = 0.01+0.03i;
z23 = 0.0125+0.025i;


% Admittance
y12 = 1/z12 
y13 = 1/z13 
y23 = 1/z23 


y11 = y12+y13;
y22=y12+y23;
y33=y13+y23;



%Y BUS MATRIX

y12=-y12;
y13=-y13;
y23=-y23;


p2=-2.566; %find out it manually
q2=-1.102i; %find out it manually
p3=-1.386; %find out it manually
q3=-0.452i; %find out it manually


v1=1.05+0i;
v2=1+0i;
v3=1+0i;

iter = 0;

for k = 0:6
    
    iter = iter +1
    
    v2 = ((p2-q2)/conj(v2)-((y12)*v1)-(y23*v3))/(y22)
    v22 = [abs(v2)  (angle(v2))*(180/pi)]
    v3 = (((p3-q3)/conj(v3))-((y13*v1)+(y23*v2)))/(y33)
    v33= [abs(v3)  (angle(v3))*(180/pi)]

    
end
y12=-y12;
y13=-y13;
y23=-y23;

PQ1 =( conj(v1)*((v1*((y12+y13)))-((y12)*v2)-((y13)*v3)));

pQq1=(1.05*((1.05*((20-50i)))-((10-20i)*(.98-.06i))-((10-30i)*(1.0000 - 0.0500i)))); %both are correct

%LINE CURRENTs
I12 = y12 * (v1-v2);
I21 = - I12;
I13 = y13 * (v1-v3);
I31 = - I13;
I23 = y23 * (v2-v3);
I32 = - I23;

%LINE FLOWS
disp('LINE FLOWS')

s12 = v1 * conj(I12);
S12 = 100*(s12)

s21 = v2 * conj(I21);
S21 = 100*(s21)

s13 = v1 * conj(I13);
S13 = 100*(s13)


s31 = v3 * conj(I31);
S31 = 100*(s31)


s23 = v2 * conj(I23);
S23 = 100*(s23)


s32 = v3 * conj(I32);
S32 = 100*(s32)


%LINE LOSSES
disp('LOSSES')

SL12 = S12+S21
SL13=S13+S31
SL23=S23+S32